"""
    系统文件控制器
"""


class OperationController:
    def open(self, file):
        file.open()















