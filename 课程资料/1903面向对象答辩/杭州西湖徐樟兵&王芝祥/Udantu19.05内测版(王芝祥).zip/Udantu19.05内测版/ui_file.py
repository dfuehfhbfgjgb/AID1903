from operation_controller import *


class FileView:
    def __init__(self, list_files):
        self.__list_dir = list_files
        self.__operation_controller = OperationController()
        # self.__account = account

    def __display_menu(self):
        print('0)..', end='   ')
        for i in range(1, len(self.__list_dir) + 1):
            print("%d)%s" % (i, self.__list_dir[i - 1].name), end='   ')
        print('')

    def __select_menu(self):
        number = int(input("请选择:"))
        if number != 0:
            self.__operation_controller.open(self.__list_dir[number-1])
            return True
        return False

    def main(self):
        loop = True
        while loop:
            self.__display_menu()
            loop = self.__select_menu()

