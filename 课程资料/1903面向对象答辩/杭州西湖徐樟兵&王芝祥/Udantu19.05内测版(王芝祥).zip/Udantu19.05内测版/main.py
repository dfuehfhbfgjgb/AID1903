from ui_login import *


if __name__ == '__main__':
    v01 = LoginView()
    v01.main()
