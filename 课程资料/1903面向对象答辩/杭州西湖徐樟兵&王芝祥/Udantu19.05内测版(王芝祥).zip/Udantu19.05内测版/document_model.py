"""
    文件类
"""
from ui_file import *
from ui_account_set import *


class File:
    def __init__(self, name):
        self.__name = name

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    def open(self):
        raise NotImplementedError()


class Directory(File):
    """
        文件夹
    """
    def __init__(self, name, list_files=[]):
        super().__init__(name)
        self.__list_files = list_files

    @property
    def list_files(self):
        return self.__list_files

    def open(self):
        view_directory = FileView(self.__list_files)
        view_directory.main()


class Document(File):
    """
        文件
    """
    def __init__(self, name):
        super().__init__(name + '.doc')

    def open(self):
        print("执行doc文件main函数")


class Application(File):
    """
        应用程序
    """
    def __init__(self, name, app):
        super().__init__(name + '.app')
        self.app = app

    def open(self):
        # self.app.main()
        print("执行app文件main函数")


class Root:
    def __init__(self):
        self.__list_files = [Directory("我的电脑", [Application("账户设置", AccountSet())]), Document("学习python从入门到入土")]

    @property
    def list_files(self):
        return self.__list_files

    def open(self):
        view_directory = FileView(self.__list_files)
        view_directory.main()



