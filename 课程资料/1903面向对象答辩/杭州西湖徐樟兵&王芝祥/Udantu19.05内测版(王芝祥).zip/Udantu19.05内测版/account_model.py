"""
    model 数据模型层
"""


class Account:
    """
        账户数据模型类
    """
    list_direction = []

    def __init__(self, name="Administrator", pwd=None):
        self.name = name
        self.pwd = pwd

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def pwd(self):
        return self.__pwd

    @pwd.setter
    def pwd(self, value):
        self.__pwd = value

    def add_dir(self, directory):
        raise NotImplementedError()

    def delete_dir(self, directory):
        raise NotImplementedError()

    def open_dir(self, directory):
        raise NotImplementedError()


class Admin(Account):
    def add_dir(self, directory):
        raise NotImplementedError()

    def delete_dir(self, directory):
        raise NotImplementedError()

    def open_dir(self, directory):
        raise NotImplementedError()


class User(Account):
    def add_dir(self, directory):
        raise NotImplementedError()

    def delete_dir(self, directory):
        raise NotImplementedError()

    def open_dir(self, directory):
        raise NotImplementedError()


class Guest(Account):
    def add_dir(self, directory):
        raise NotImplementedError()

    def delete_dir(self, directory):
        raise NotImplementedError()

    def open_dir(self, directory):
        raise NotImplementedError()



