"""
    系统操作界面
"""
from operation_controller import *
from document_model import *


class OperationView:
    def __init__(self, account):
        self.__list_dir = Root().list_files
        self.__operation_controller = OperationController()
        self.__account = account

    def __display_menu(self):
        print('0)关机', end='   ')
        for i in range(1, len(self.__list_dir)+1):
            print("%d)%s" % (i, self.__list_dir[i-1].name), end='   ')
        print('')

    def __select_menu(self):
        number = int(input("请选择:"))
        if number != 0:
            self.__operation_controller.open(self.__list_dir[number-1])
        else:
            return False
        return True

    def main(self):
        loop = True
        while loop:
            self.__display_menu()
            loop = self.__select_menu()




