"""
    账户控制器
"""
from account_model import *


class AccountController:
    def __init__(self):
        self.__list_account = [Admin()]

    @property
    def list_account(self):
        return self.__list_account

    def add_account(self, account):
        self.__list_account.append(account)

    def remove_account(self, acc):
        pass












