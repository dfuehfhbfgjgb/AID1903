"""
    系统登录界面
"""
from account_controller import *
from ui_operation import *
import time


class LoginView:
    def __init__(self):
        self.__account_controller = AccountController()

    def __load_menu(self, sec):
        scale = 45
        print("----------------------开机中----------------------")
        start = time.perf_counter()
        for i in range(scale + 1):
            a = '*' * i
            b = '.' * (scale - i)
            c = (i / scale) * 100
            dur = time.perf_counter() - start
            print("\r{:^3.0f}%[{}->{}]{:.2f}s".format(c, a, b, dur),
                  end='')
            time.sleep(sec/70)
        print("\n" + "-------------开机完成，1s后进入系统！-------------")
        time.sleep(1)

    def __shut_menu(self):
        print('''----------------------关机中----------------------''')
        time.sleep(1)

    def __boot_menu(self):
        print('''
         ************************************
         **  欢迎使用 Udantu 19.05 内测版  **
         ************************************''')
        self.__load_menu(10)

    def __output_accounts(self, list_target):
        for i in range(len(list_target)):
            print("%d) %s" % (i, list_target[i].name))

    def __select_menu(self, list_target):
        """
        选择菜单
        :return:
        """
        print("q) 关机")

        input_str = input("请选择要登录的账户:")
        if input_str == 'q':
            pass
        else:
            operation_view = OperationView(list_target[int(input_str)])
            operation_view.main()

    def main(self):
        self.__boot_menu()
        self.__output_accounts(self.__account_controller.list_account)
        self.__select_menu(self.__account_controller.list_account)
        self.__shut_menu()


if __name__ == '__main__':
    v01 = LoginView()
    v01.main()




















